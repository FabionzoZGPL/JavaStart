 class Method {

    double BMI (double wzrost, double waga){
        double wzrost2 = wzrost/100;
        return waga/(wzrost2*wzrost2);
    }
}
