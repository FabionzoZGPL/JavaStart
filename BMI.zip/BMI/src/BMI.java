import java.util.Scanner;

public class BMI{
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Witaj w kalkulatorze BMI!");
        System.out.println("W celu obliczenia Twojego indeksu proszę o podanie wagi oraz wzrostu.");

        System.out.print("Twój wzrost w centymetrach to: ");
        Scanner scanner1 = new Scanner(System.in);
        double wzrost = scanner1.nextDouble();

        System.out.print("Twoja waga w kilogramach to: ");
        Scanner scanner2 = new Scanner(System.in);
        double waga = scanner2.nextDouble();

        Method method = new Method();
        double bmi = method.BMI(wzrost, waga);

        System.out.println("Przy wzroście "+wzrost+" i wadze "+waga+" Twoje BMI wynosi "+bmi);

        if ((bmi >= 18.5) && (bmi <= 24.9)){
            System.out.println(" Twoje BMI jest w normie");
        } if  (bmi > 24.9) {
            System.out.println("Tłuścioch ;)");
        } if  ( bmi < 18.5){
            System.out.println("Człowieku, zacznij jeść!!");
        }
    }

}
